package com.example.eventtrackingapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val username = findViewById<EditText>(R.id.etUsername)
        val password = findViewById<EditText>(R.id.etPassword)

        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            if (username.text.toString().trim().isEmpty() || password.text.toString().isEmpty()) {
                Toast.makeText(this, "Enter both username and password.", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(this, DashboardActivity::class.java))
            }
        }

        findViewById<Button>(R.id.btnCreateAccount).setOnClickListener {
            if (username.text.toString().trim().isEmpty() || password.text.toString().isEmpty()) {
                Toast.makeText(this, "Enter a username and password to create an account.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Account UI submitted. Database support will be completed in Project Three.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
