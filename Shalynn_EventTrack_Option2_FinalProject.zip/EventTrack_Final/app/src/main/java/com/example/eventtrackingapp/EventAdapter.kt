package com.example.eventtrackingapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EventAdapter(
    private val events: MutableList<Event>,
    private val onEventClick: (Event) -> Unit,
    private val onDeleteClick: (Event) -> Unit
) : RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    class EventViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val date: TextView = view.findViewById(R.id.tvEventDate)
        val name: TextView = view.findViewById(R.id.tvEventName)
        val time: TextView = view.findViewById(R.id.tvEventTime)
        val delete: Button = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_event, parent, false)
        return EventViewHolder(view)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val event = events[position]
        holder.date.text = event.date
        holder.name.text = event.name
        holder.time.text = "${event.time} • ${event.location}"

        holder.itemView.setOnClickListener { onEventClick(event) }
        holder.delete.setOnClickListener { onDeleteClick(event) }
    }

    override fun getItemCount(): Int = events.size
}
