package com.example.eventtrackingapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class SmsNotificationActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var phone: EditText
    private lateinit var message: EditText

    private val requestSmsPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                status.text = "SMS permission granted."
                result.text = "Permission granted. Event reminders can be enabled."
                Toast.makeText(this, "SMS reminders enabled.", Toast.LENGTH_SHORT).show()
            } else {
                status.text = "SMS permission denied."
                result.text = "SMS reminders are disabled, but the rest of the app can continue to function."
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms_notification)

        status = findViewById(R.id.tvSmsPermissionStatus)
        result = findViewById(R.id.tvSmsResult)
        phone = findViewById(R.id.etPhoneNumber)
        message = findViewById(R.id.etSmsPreview)

        findViewById<Button>(R.id.btnRequestSmsPermission).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
                status.text = "SMS permission already granted."
                result.text = "Permission is available. You may use SMS reminders."
                sendTestSms()
            } else {
                requestSmsPermission.launch(Manifest.permission.SEND_SMS)
            }
        }
    }

    private fun sendTestSms() {
        val number = phone.text.toString().trim()
        val body = message.text.toString().trim()

        if (number.isEmpty() || body.isEmpty()) {
            result.text = "Permission is granted. Enter a mobile number and message to test SMS."
            return
        }

        try {
            SmsManager.getDefault().sendTextMessage(number, null, body, null, null)
            result.text = "SMS reminder sent."
        } catch (e: Exception) {
            result.text = "SMS could not be sent on this device. The app can continue without SMS reminders."
        }
    }
}
