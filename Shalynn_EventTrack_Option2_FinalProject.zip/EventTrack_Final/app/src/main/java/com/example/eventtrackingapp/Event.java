package com.example.eventtrackingapp;

public class Event {
    public long id; public String username, name, date, time, location, notes;
    public Event(long id, String username, String name, String date, String time, String location, String notes) {
        this.id=id; this.username=username; this.name=name; this.date=date; this.time=time; this.location=location; this.notes=notes;
    }
}