package com.example.eventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private EditText username, password;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = new DatabaseHelper(this);
        username=findViewById(R.id.etUsername); password=findViewById(R.id.etPassword);
        findViewById(R.id.btnLogin).setOnClickListener(v -> login());
        findViewById(R.id.btnCreateAccount).setOnClickListener(v -> createAccount());
    }

    private boolean valid() {
        if (username.getText().toString().trim().isEmpty() || password.getText().toString().trim().isEmpty()) {
            Toast.makeText(this,"Please enter a username and password.",Toast.LENGTH_SHORT).show(); return false;
        } return true;
    }
    private void createAccount() {
        if (!valid()) return;
        if (db.createUser(username.getText().toString().trim(), password.getText().toString())) {
            Toast.makeText(this,"Account created. You can now log in.",Toast.LENGTH_SHORT).show();
        } else Toast.makeText(this,"That username already exists.",Toast.LENGTH_SHORT).show();
    }
    private void login() {
        if (!valid()) return;
        String u=username.getText().toString().trim(), p=password.getText().toString();
        if (db.checkLogin(u,p)) {
            getSharedPreferences("session",MODE_PRIVATE).edit().putString("username",u).apply();
            startActivity(new Intent(this,DashboardActivity.class)); finish();
        } else Toast.makeText(this,"Username or password is incorrect.",Toast.LENGTH_SHORT).show();
    }
}