package com.example.eventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {
    private DatabaseHelper db; private String user; private EventAdapter adapter;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_dashboard);
        db=new DatabaseHelper(this); user=getSharedPreferences("session",MODE_PRIVATE).getString("username","");
        if(user.isEmpty()){ startActivity(new Intent(this,LoginActivity.class)); finish(); return; }
        ((TextView)findViewById(R.id.tvWelcome)).setText("Welcome, "+user+"!");
        adapter=new EventAdapter(this, db.getEvents(user), new EventAdapter.Listener() {
            public void onOpen(Event e){ startActivity(new Intent(DashboardActivity.this,EventDetailsActivity.class).putExtra("event_id",e.id)); }
            public void onDelete(Event e){ db.deleteEvent(e.id); loadEvents(); Toast.makeText(DashboardActivity.this,"Event deleted.",Toast.LENGTH_SHORT).show(); }
        });
        RecyclerView rv=findViewById(R.id.recyclerEvents); rv.setLayoutManager(new GridLayoutManager(this,2)); rv.setAdapter(adapter);
        findViewById(R.id.btnAddEvent).setOnClickListener(v->startActivity(new Intent(this,AddEditEventActivity.class)));
        findViewById(R.id.btnSmsSettings).setOnClickListener(v->startActivity(new Intent(this,SmsNotificationActivity.class)));
    }
    private void loadEvents(){ adapter.setEvents(db.getEvents(user)); }
    @Override protected void onResume(){ super.onResume(); if(adapter!=null) loadEvents(); }
}