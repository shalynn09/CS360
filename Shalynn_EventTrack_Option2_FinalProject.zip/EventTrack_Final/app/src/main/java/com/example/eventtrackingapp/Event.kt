package com.example.eventtrackingapp

data class Event(
    val id: Int,
    val name: String,
    val date: String,
    val time: String,
    val location: String,
    val notes: String
)
