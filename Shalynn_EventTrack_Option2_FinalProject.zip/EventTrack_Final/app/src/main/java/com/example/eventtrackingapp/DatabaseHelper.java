package com.example.eventtrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "eventtrack.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL)");
        db.execSQL("CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, name TEXT NOT NULL, date TEXT NOT NULL, time TEXT, location TEXT, notes TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS events");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    public boolean createUser(String username, String password) {
        ContentValues v = new ContentValues();
        v.put("username", username); v.put("password", password);
        return getWritableDatabase().insert("users", null, v) != -1;
    }

    public boolean checkLogin(String username, String password) {
        Cursor c = getReadableDatabase().rawQuery("SELECT id FROM users WHERE username=? AND password=?", new String[]{username,password});
        boolean ok = c.moveToFirst(); c.close(); return ok;
    }

    public long addEvent(String user, String name, String date, String time, String location, String notes) {
        ContentValues v = new ContentValues();
        v.put("username", user); v.put("name", name); v.put("date", date); v.put("time", time);
        v.put("location", location); v.put("notes", notes);
        return getWritableDatabase().insert("events", null, v);
    }

    public List<Event> getEvents(String user) {
        List<Event> list = new ArrayList<>();
        Cursor c = getReadableDatabase().query("events", null, "username=?", new String[]{user}, null, null, "date ASC, time ASC");
        while (c.moveToNext()) list.add(eventFromCursor(c));
        c.close(); return list;
    }

    public Event getEvent(long id) {
        Cursor c = getReadableDatabase().query("events", null, "id=?", new String[]{String.valueOf(id)}, null, null, null);
        Event e = c.moveToFirst() ? eventFromCursor(c) : null; c.close(); return e;
    }

    private Event eventFromCursor(Cursor c) {
        return new Event(c.getLong(c.getColumnIndexOrThrow("id")),
                c.getString(c.getColumnIndexOrThrow("username")),
                c.getString(c.getColumnIndexOrThrow("name")),
                c.getString(c.getColumnIndexOrThrow("date")),
                c.getString(c.getColumnIndexOrThrow("time")),
                c.getString(c.getColumnIndexOrThrow("location")),
                c.getString(c.getColumnIndexOrThrow("notes")));
    }

    public int updateEvent(Event e) {
        ContentValues v = new ContentValues();
        v.put("name", e.name); v.put("date", e.date); v.put("time", e.time);
        v.put("location", e.location); v.put("notes", e.notes);
        return getWritableDatabase().update("events", v, "id=?", new String[]{String.valueOf(e.id)});
    }

    public int deleteEvent(long id) {
        return getWritableDatabase().delete("events", "id=?", new String[]{String.valueOf(id)});
    }
}