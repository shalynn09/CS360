package com.example.eventtrackingapp;

import android.Manifest; import android.content.pm.PackageManager; import android.os.Bundle; import android.telephony.SmsManager; import android.widget.*; import androidx.appcompat.app.AppCompatActivity; import androidx.core.app.ActivityCompat; import androidx.core.content.ContextCompat;

public class SmsNotificationActivity extends AppCompatActivity {
    private static final int SMS_REQUEST=100; TextView status,result; EditText phone,message;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_sms_notification);
        status=findViewById(R.id.tvSmsPermissionStatus);result=findViewById(R.id.tvSmsResult);phone=findViewById(R.id.etPhoneNumber);message=findViewById(R.id.etSmsPreview);
        findViewById(R.id.btnRequestSmsPermission).setOnClickListener(v->requestOrSend()); updateStatus();
    }
    private void requestOrSend(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS},SMS_REQUEST);}else sendSms();}
    private void updateStatus(){boolean granted=ContextCompat.checkSelfPermission(this,Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED;status.setText(granted?"SMS permission is granted.":"SMS permission has not been granted.");}
    private void sendSms(){String number=phone.getText().toString().trim(), msg=message.getText().toString().trim();if(number.isEmpty()||msg.isEmpty()){result.setText("Enter a mobile number and reminder message.");return;}try{SmsManager.getDefault().sendTextMessage(number,null,msg,null,null);result.setText("SMS reminder sent successfully.");}catch(Exception e){result.setText("SMS could not be sent. The rest of EventTrack will continue to work.");}}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==SMS_REQUEST){updateStatus();if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)result.setText("Permission granted. Tap Allow SMS Reminders again to send the reminder.");else result.setText("SMS permission denied. EventTrack will continue without SMS reminders.");}}
}