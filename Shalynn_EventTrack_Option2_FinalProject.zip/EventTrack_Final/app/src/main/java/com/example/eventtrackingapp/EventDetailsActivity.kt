package com.example.eventtrackingapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class EventDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event_details)

        findViewById<TextView>(R.id.tvDetailName).text = intent.getStringExtra("event_name")
        findViewById<TextView>(R.id.tvDetailDate).text = "Date: ${intent.getStringExtra("event_date")}"
        findViewById<TextView>(R.id.tvDetailTime).text = "Time: ${intent.getStringExtra("event_time")}"
        findViewById<TextView>(R.id.tvDetailLocation).text = "Location: ${intent.getStringExtra("event_location")}"
        findViewById<TextView>(R.id.tvDetailNotes).text = "Notes: ${intent.getStringExtra("event_notes")}"

        findViewById<Button>(R.id.btnEditEvent).setOnClickListener {
            Toast.makeText(this, "Edit screen will connect to the database in Project Three.", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnDeleteEvent).setOnClickListener {
            Toast.makeText(this, "Delete action selected.", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
