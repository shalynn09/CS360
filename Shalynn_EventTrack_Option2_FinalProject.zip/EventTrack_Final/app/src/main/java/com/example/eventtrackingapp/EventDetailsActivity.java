package com.example.eventtrackingapp;

import android.content.Intent; import android.os.Bundle; import androidx.appcompat.app.AppCompatActivity; import android.widget.*; import android.content.DialogInterface;

public class EventDetailsActivity extends AppCompatActivity {
    DatabaseHelper db; long id;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_event_details);db=new DatabaseHelper(this);id=getIntent().getLongExtra("event_id",-1);load();
        findViewById(R.id.btnEditEvent).setOnClickListener(v->startActivity(new Intent(this,AddEditEventActivity.class).putExtra("event_id",id)));
        findViewById(R.id.btnDeleteEvent).setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Delete event?").setMessage("This cannot be undone.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{db.deleteEvent(id);finish();}).show());
    }
    void load(){Event e=db.getEvent(id);if(e==null){finish();return;}((TextView)findViewById(R.id.tvDetailName)).setText(e.name);((TextView)findViewById(R.id.tvDetailDate)).setText("Date: "+e.date);((TextView)findViewById(R.id.tvDetailTime)).setText("Time: "+e.time);((TextView)findViewById(R.id.tvDetailLocation)).setText("Location: "+e.location);((TextView)findViewById(R.id.tvDetailNotes)).setText("Notes: "+e.notes);}
    @Override protected void onResume(){super.onResume();if(db!=null)load();}
}