package com.example.eventtrackingapp

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AddEditEventActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_edit_event)

        findViewById<Button>(R.id.btnSaveEvent).setOnClickListener {
            Toast.makeText(this, "Event saved in the UI. Database support will be completed in Project Three.", Toast.LENGTH_LONG).show()
            finish()
        }

        findViewById<Button>(R.id.btnCancelEvent).setOnClickListener {
            finish()
        }
    }
}
