package com.example.eventtrackingapp;

import android.content.Context;
import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.Holder> {
    public interface Listener { void onOpen(Event e); void onDelete(Event e); }
    private final Context context; private List<Event> events; private final Listener listener;
    public EventAdapter(Context c,List<Event> e,Listener l){context=c;events=e;listener=l;}
    public void setEvents(List<Event> e){events=e;notifyDataSetChanged();}
    @Override public Holder onCreateViewHolder(ViewGroup p,int v){return new Holder(LayoutInflater.from(context).inflate(R.layout.item_event,p,false));}
    @Override public void onBindViewHolder(Holder h,int pos){ Event e=events.get(pos);
        h.date.setText(e.date); h.name.setText(e.name); h.time.setText(e.time+" • "+e.location);
        h.itemView.setOnClickListener(v->listener.onOpen(e)); h.delete.setOnClickListener(v->listener.onDelete(e));
    }
    @Override public int getItemCount(){return events.size();}
    static class Holder extends RecyclerView.ViewHolder {
        TextView date,name,time; Button delete;
        Holder(View v){super(v);date=v.findViewById(R.id.tvEventDate);name=v.findViewById(R.id.tvEventName);time=v.findViewById(R.id.tvEventTime);delete=v.findViewById(R.id.btnDelete);}
    }
}