package com.example.eventtrackingapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DashboardActivity : AppCompatActivity() {

    private val events = mutableListOf(
        Event(1, "Project Meeting", "AUG 12", "10:00 AM", "Office", "Discuss project milestones."),
        Event(2, "Family Appointment", "AUG 14", "2:30 PM", "Medical Center", "Bring required paperwork."),
        Event(3, "Dinner with Friends", "AUG 16", "6:30 PM", "Downtown", "Reservation at 6:30 PM."),
        Event(4, "Class Assignment", "AUG 18", "11:59 PM", "Online", "Submit final assignment.")
    )

    private lateinit var adapter: EventAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val recycler = findViewById<RecyclerView>(R.id.recyclerEvents)
        adapter = EventAdapter(events,
            onEventClick = { event ->
                val intent = Intent(this, EventDetailsActivity::class.java)
                intent.putExtra("event_name", event.name)
                intent.putExtra("event_date", event.date)
                intent.putExtra("event_time", event.time)
                intent.putExtra("event_location", event.location)
                intent.putExtra("event_notes", event.notes)
                startActivity(intent)
            },
            onDeleteClick = { event ->
                events.remove(event)
                adapter.notifyDataSetChanged()
                Toast.makeText(this, "Event removed from the UI.", Toast.LENGTH_SHORT).show()
            }
        )

        recycler.layoutManager = GridLayoutManager(this, 2)
        recycler.adapter = adapter

        findViewById<Button>(R.id.btnAddEvent).setOnClickListener {
            startActivity(Intent(this, AddEditEventActivity::class.java))
        }

        findViewById<Button>(R.id.btnSmsSettings).setOnClickListener {
            startActivity(Intent(this, SmsNotificationActivity::class.java))
        }
    }
}
