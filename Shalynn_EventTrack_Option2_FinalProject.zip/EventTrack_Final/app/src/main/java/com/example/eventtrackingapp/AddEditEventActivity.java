package com.example.eventtrackingapp;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class AddEditEventActivity extends AppCompatActivity {
    DatabaseHelper db; EditText name,date,time,location,notes; long eventId=-1;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_add_edit_event);
        db=new DatabaseHelper(this); name=findViewById(R.id.etEventName);date=findViewById(R.id.etEventDate);time=findViewById(R.id.etEventTime);location=findViewById(R.id.etEventLocation);notes=findViewById(R.id.etEventNotes);
        eventId=getIntent().getLongExtra("event_id",-1);
        if(eventId!=-1){ ((TextView)findViewById(R.id.tvEventFormTitle)).setText("Edit Event"); Event e=db.getEvent(eventId); if(e!=null){name.setText(e.name);date.setText(e.date);time.setText(e.time);location.setText(e.location);notes.setText(e.notes);} }
        findViewById(R.id.btnSaveEvent).setOnClickListener(v->save()); findViewById(R.id.btnCancelEvent).setOnClickListener(v->finish());
    }
    void save(){String n=name.getText().toString().trim(),d=date.getText().toString().trim(); if(n.isEmpty()||d.isEmpty()){Toast.makeText(this,"Event name and date are required.",Toast.LENGTH_SHORT).show();return;}
        String u=getSharedPreferences("session",MODE_PRIVATE).getString("username","");
        Event e=new Event(eventId,u,n,d,time.getText().toString().trim(),location.getText().toString().trim(),notes.getText().toString().trim());
        if(eventId==-1) db.addEvent(u,e.name,e.date,e.time,e.location,e.notes); else db.updateEvent(e);
        Toast.makeText(this,"Event saved.",Toast.LENGTH_SHORT).show();finish();}
}